-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 29, 2026 at 11:47 PM
-- Server version: 8.0.44-0ubuntu0.22.04.1
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demow2DB`
--
CREATE DATABASE IF NOT EXISTS `demow2DB` DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci;
USE `demow2DB`;

-- --------------------------------------------------------

--
-- Table structure for table `t_account`
--

CREATE TABLE `t_account` (
  `ACC_USER` varchar(50) NOT NULL,
  `ACC_PASS` varchar(50) NOT NULL,
  `ACC_NAME` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `t_account`
--

INSERT INTO `t_account` (`ACC_USER`, `ACC_PASS`, `ACC_NAME`) VALUES
('admin', '123456', 'Quản trị viên - Nguyễn Bé Yêu');

-- --------------------------------------------------------

--
-- Table structure for table `t_account1`
--

CREATE TABLE `t_account1` (
  `ACC_USER` varchar(50) NOT NULL,
  `ACC_PASS` varchar(255) NOT NULL,
  `ACC_NAME` varchar(100) DEFAULT NULL,
  `ACC_ROLE` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `t_account1`
--

INSERT INTO `t_account1` (`ACC_USER`, `ACC_PASS`, `ACC_NAME`, `ACC_ROLE`) VALUES
('admin', '$2y$10$3GAj11D8Rk87iSFoAGGf9.w/TcbB.ZKeCPs3SlMRbrMvLAetDtUEq', 'Quản trị viên', 1),
('Conga', '$2y$10$CbQtvoed8w0kezs3JX36BOuxkECQ0q9Fwh1f4wZdEL1ji9o8AreYC', 'Con gà mái', 0),
('congau', '$2y$10$22iZyLZ9/EMay4jkzvKh0ueJd4Jh00Xj1IPku6xUUK0CDfN.ziI.m', 'Con gấu', 0),
('conmeo', '$2y$10$7/hiKayTIseAQB3Imscltu4bt7q7A5MEvRUguNKcw1KBpB2NJtuV.', 'con mèo', 0),
('contho', '$2y$10$qZEgFnQQh7B/D1pArNGsT.La/Vs3awXttG52uspvUxH30jzL7L53O', 'con thỏ', 0),
('contrau', '$2y$10$/I1HAdfiTq4.fCQmuByzSO9KEs7W7z95n2KJ4dITI1zpbgEi0NuCK', 'Con trâu', 0),
('khachhang', '$2y$10$R/I7ExoTrBclVMYax/pjAef4cYM70UgzmBFdBgi5twMzd0aa8Jacu', 'Nguyễn Văn A', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_book`
--

CREATE TABLE `t_book` (
  `BOOK_ID` int NOT NULL,
  `BOOK_TITLE` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `BOOK_DESC` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `BOOK_CATID` int DEFAULT NULL,
  `BOOK_AUTHOR` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `BOOK_PUBID` int DEFAULT NULL,
  `BOOK_YEAR` int DEFAULT NULL,
  `BOOK_PIC` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `BOOK_PRICE` int DEFAULT NULL,
  `BOOK_RATE` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_book`
--

INSERT INTO `t_book` (`BOOK_ID`, `BOOK_TITLE`, `BOOK_DESC`, `BOOK_CATID`, `BOOK_AUTHOR`, `BOOK_PUBID`, `BOOK_YEAR`, `BOOK_PIC`, `BOOK_PRICE`, `BOOK_RATE`) VALUES
(1, 'Chìa khóa Văn phạm tiếng Anh', 'Cuốn sách Chìa Khóa Văn Phạm Tiếng Anh đã được biên soạn bao gồm những phần ngữ pháp rất cơ bản ở chương trình phổ thông. Cho nên, nó rất hữu ích với tất cả các bạn học sinh nào muốn học tốt tiếng Anh. Cuốn sách trình bày rất rõ ràng và từ vựng rất dễ hiểu. Sau mỗi bài đều có nhiều bài tập để rèn luyện và sau mỗi phần đều có bài tập tổng hợp từ dễ đến khó', 4, 'Nguyễn Văn gà con', 4, 2002, 'ckvptienganh.jpg', 6500, NULL),
(2, 'Adobe Photoshop 7', 'Giới thiệu những đặc tính mới trong Photoshop 7\r\nĐề cập tới những khái niệm cơ bản về màu và tính năng quản lý màu của Photoshop\r\nTìm hiểu về lớp, mặt nạ và bộ lọc\r\nHọc cách tạo, biến ảnh, dịch chuyển lớp chữ, tạo hiệu ứng chữ,v.v\r\nLàm quen với bộ công cụ tô vẽ của Photoshop, tô điểm ảnh quét hoặc vẽ nên một \"tuyệt tác\" từ trang giấy trắng.', 1, 'VN-GUIDE', 3, 2003, 'Photoshop7.jpg', 69000, 1),
(4, 'Tiếng Anh trong phỏng vấn', 'Cuốn sách sẽ hướng dẫn bạn những cách thức khi đi phỏng vấn tìm việc làm, tự giới thiệu như thế nào về bản thân, về đời sống, gia đình, tính cách, quan điểm,... Sách sẽ là tài liệu tham khảo tốt cho những ai đang cần tìm việc làm tại các công ty nước ngoài.\r\nXint rân trọng giới thiệu.', 4, 'Nguyễn Thành Yến', 5, 2003, 'TiengAnhPVan.jpg', 36000, 0),
(5, 'Hướng dẫn sử dụng Swish', 'Nếu có lúc nào đó lang thang trên mạng, chúng ta thấy nhiều trang Web có các hàng tiêu đề xuất hiện với nhiều hiệu ứng trông rất bắt mắt và nếu các bạn đã sử dụng Flash trong thiết kế sẽ nghĩ không biết để tạo hiệu ứng sống động như thế trên văn bản thì phải dùng cách nào? Flash có thể làm được nhưng mất rất nhiều thời gian và công sức. Thực ra các nhà thiết kế đã sử dụng các trình ứng dụng của các hãng thứ ba để việc thiết kế dễ dàng hơn. Có một vài chương trình nổi tiếng, trong số đó phải kể đến Swish.', 1, 'Ph?m Quang Huy', 3, 2003, 'sudungswish.jpg', 45000, 0),
(8, 'Thiết kế lập trình Web với DreamWeaver', 'Sách hay !', 2, 'Nguyễn Thị Hồng', 2, 2006, 'TiengAnhPVan.jpg', 22000, 5),
(11, 'con gà', 'con gà trống', NULL, 'con gà mái', NULL, 2025, 'concasau.png', NULL, NULL),
(12, 'con chim sẻ', 'một con chim mập', NULL, 'con quạ', NULL, 2016, NULL, NULL, NULL),
(13, 'chim xứ quá lạnh', 'con chim cánh cụt', NULL, 'con chim cụt cánh', NULL, 2016, 'canhcut.png', NULL, NULL),
(14, 'con thỏ con', 'con thỏ mập', NULL, 'con thỏ cha', NULL, 2015, 'Contho.png', NULL, NULL),
(899, 'Be Yeu Nguyen xinh dep ', 'De thuong nhung thuong ko de', 2, 'Con meo', 4, 2025, NULL, 12, 1),
(9934, 'Be Khanh Duy vui khong???', 'Met qua tui minh nghi hong?', 2, 'Con ga', 2, 2025, NULL, 1, 1),
(9990, 'Ngay nao Linh cung cuoi', 'Khoai cuoi du lam', 2, 'Con ga', 3, 2026, 'concasau.png', 1, 1),
(9991, 'Con mèo', 'con mèo mập', NULL, 'con chó', NULL, 2025, '12006309_485727158267841_7189126814909549888_n.jpg', NULL, NULL),
(9992, 'con mèo trên cửa sổ', 'có 1 con mèo mập', NULL, 'con chó', NULL, 2025, 'ip1-3.webp', NULL, NULL),
(9993, 'con mèo đen', 'một con mèo mập', NULL, 'con mèo', NULL, 2026, 'conmeoheo.png', NULL, NULL),
(9994, '1 con hà mã', 'hà mã sống dưới nước', NULL, 'con hà mã', NULL, 2025, NULL, NULL, NULL),
(9995, 'cây dừa', 'dừa bến tre', NULL, 'con gà', NULL, 2024, NULL, NULL, NULL),
(9996, 'solo leveling', 'hay lắm nè', NULL, 'con mèo', NULL, 2025, 'cho.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `t_category`
--

CREATE TABLE `t_category` (
  `CAT_ID` int NOT NULL,
  `CAT_NAME` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `CAT_DESC` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_category`
--

INSERT INTO `t_category` (`CAT_ID`, `CAT_NAME`, `CAT_DESC`) VALUES
(1, 'Tin học', NULL),
(2, 'Khoa học Kỹ thuật', NULL),
(3, 'Khoa học Xã hội', NULL),
(4, 'Ngoại ngữ', NULL),
(5, 'Kinh tế', NULL),
(6, 'Mỹ thuật - Điện ảnh', NULL),
(7, 'Thơ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `t_pub`
--

CREATE TABLE `t_pub` (
  `PUB_ID` int NOT NULL,
  `PUB_NAME` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `PUB_ADDR` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_pub`
--

INSERT INTO `t_pub` (`PUB_ID`, `PUB_NAME`, `PUB_ADDR`) VALUES
(1, 'Giáo dục', NULL),
(2, 'Khoa học kỹ thuật', NULL),
(3, 'Thống kê', NULL),
(4, 'Trẻ', NULL),
(5, 'Tp. Hồ Chí Minh', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `t_user`
--

CREATE TABLE `t_user` (
  `USER_ID` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `USER_PASSWORD` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `USER_EMAIL` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `USER_PHONE` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `USER_ADDR` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_user`
--

INSERT INTO `t_user` (`USER_ID`, `USER_PASSWORD`, `USER_NAME`, `USER_EMAIL`, `USER_PHONE`, `USER_ADDR`) VALUES
('admin', 'admin', 'Quản trị hệ thống', NULL, NULL, NULL),
('lvminh', 'abc', NULL, NULL, NULL, NULL),
('ttbhanh', '123', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_account`
--
ALTER TABLE `t_account`
  ADD PRIMARY KEY (`ACC_USER`);

--
-- Indexes for table `t_account1`
--
ALTER TABLE `t_account1`
  ADD PRIMARY KEY (`ACC_USER`);

--
-- Indexes for table `t_book`
--
ALTER TABLE `t_book`
  ADD PRIMARY KEY (`BOOK_ID`),
  ADD KEY `BOOK_CATID` (`BOOK_CATID`),
  ADD KEY `BOOK_ID` (`BOOK_ID`),
  ADD KEY `BOOK_PUBID` (`BOOK_PUBID`),
  ADD KEY `T_CATEGORYT_BOOK` (`BOOK_CATID`),
  ADD KEY `T_PUBT_BOOK` (`BOOK_PUBID`);

--
-- Indexes for table `t_category`
--
ALTER TABLE `t_category`
  ADD PRIMARY KEY (`CAT_ID`),
  ADD KEY `CAT_ID` (`CAT_ID`);

--
-- Indexes for table `t_pub`
--
ALTER TABLE `t_pub`
  ADD PRIMARY KEY (`PUB_ID`),
  ADD KEY `PUB_ID` (`PUB_ID`);

--
-- Indexes for table `t_user`
--
ALTER TABLE `t_user`
  ADD PRIMARY KEY (`USER_ID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_book`
--
ALTER TABLE `t_book`
  MODIFY `BOOK_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9997;

--
-- AUTO_INCREMENT for table `t_category`
--
ALTER TABLE `t_category`
  MODIFY `CAT_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `t_pub`
--
ALTER TABLE `t_pub`
  MODIFY `PUB_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
