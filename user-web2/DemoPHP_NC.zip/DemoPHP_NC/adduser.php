<?php
require 'check_login1.php';
require 'DataProvider3.php';

$message = "";
$message_color = "green";

// Xử lý khi người dùng nhấn nút "Tạo tài khoản"
if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['pass_confirm'])) {
    $u = $_POST['user'];
    $p = $_POST['pass'];
    $p_confirm = $_POST['pass_confirm'];
    $n = $_POST['name'];
    $r = $_POST['role'];

    // 1. Kiểm tra hai mật khẩu có khớp nhau không
    if ($p !== $p_confirm) {
        $message = "Lỗi: Mật khẩu nhập lại không khớp!";
        $message_color = "red";
    } else {
        $dp = new DataProvider();
        
        // 2. Kiểm tra xem User ID đã tồn tại chưa
        $check_sql = "SELECT * FROM t_account1 WHERE ACC_USER = '$u'";
        $check_result = $dp->executeQuery($check_sql);

        if ($check_result->num_rows > 0) {
            $message = "Lỗi: Tên đăng nhập này đã tồn tại!";
            $message_color = "red";
        } else {
            // 3. Mã hóa mật khẩu sau khi đã kiểm tra mọi thứ ổn định
            $hashed_password = password_hash($p, PASSWORD_DEFAULT);

            // 4. Chèn dữ liệu vào bảng t_account1
            $sql = "INSERT INTO t_account1 (ACC_USER, ACC_PASS, ACC_NAME, ACC_ROLE) 
                    VALUES ('$u', '$hashed_password', '$n', $r)";
            
            $result = $dp->executeQuery($sql);

            if ($result) {
                $message = "Tạo tài khoản thành công!";
                $message_color = "green";
            } else {
                $message = "Lỗi trong quá trình lưu dữ liệu.";
                $message_color = "red";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Thêm người dùng mới</title>
    <meta charset="utf-8">
    <style>
        .container { width: 450px; margin: 40px auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .form-group { margin-bottom: 12px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 0.9em; }
        input[type="text"], input[type="password"], select { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .btn { background: #007bff; color: white; padding: 12px; border: none; cursor: pointer; width: 100%; border-radius: 4px; font-size: 1em; }
        .btn:hover { background: #0056b3; }
        .msg { padding: 10px; margin-bottom: 15px; border-radius: 4px; text-align: center; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <h2 style="text-align: center; color: #333;">Tạo Tài Khoản Mới</h2>
    
    <?php if($message != ""): ?>
        <div class="msg" style="background-color: <?php echo ($message_color == 'red' ? '#f8d7da' : '#d4edda'); ?>; color: <?php echo $message_color; ?>; border: 1px solid <?php echo $message_color; ?>;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form action="adduser.php" method="post" style="border: 1px solid #ddd; padding: 25px; border-radius: 8px; background: #fff; shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <div class="form-group">
            <label>Tên đăng nhập (User ID):</label>
            <input type="text" name="user" required value="<?php echo isset($_POST['user']) ? $_POST['user'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Họ và tên người dùng:</label>
            <input type="text" name="name" required value="<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>">
        </div>

        <div class="form-group">
            <label>Mật khẩu:</label>
            <input type="password" name="pass" required>
        </div>

        <div class="form-group" style="background: #fdfdfe; border-left: 4px solid #ffc107; padding-left: 10px;">
            <label>Xác nhận mật khẩu:</label>
            <input type="password" name="pass_confirm" required>
        </div>

        <div class="form-group">
            <label>Quyền hạn:</label>
            <select name="role">
                <option value="0">Người mua hàng (Customer)</option>
                <option value="1">Quản trị hệ thống (Admin)</option>
            </select>
        </div>

        <button type="submit" class="btn">Đăng ký tài khoản</button>
    </form>
    
    <p style="text-align: center; margin-top: 20px;">
        <a href="login1.php" style="text-decoration: none; color: #666;">← Quay lại trang đăng nhập</a>
    </p>
</div>

</body>
</html>