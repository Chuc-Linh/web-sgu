<?php
class DataProvider {
    private $conn;

    public function __construct() {
        require 'db1.inc';
        $this->conn = new mysqli($servername, $username, $password, $dbname);

        if ($this->conn->connect_error) {
            die("Kết nối thất bại: " . $this->conn->connect_error);
        }
        $this->conn->set_charset("utf8"); // hỗ trợ utf8 nếu cần
       // echo "thành công !!!";
    }

    public function executeQuery($query) {
        $result = $this->conn->query($query);
        return $result;
    }

    public function __destruct() {
        $this->conn->close();
    }
}
?>
