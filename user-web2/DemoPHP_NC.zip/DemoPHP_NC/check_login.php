<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    // Nếu chưa đăng nhập, đá người dùng về trang login
    header("Location: login.php");
    exit();
}
?>