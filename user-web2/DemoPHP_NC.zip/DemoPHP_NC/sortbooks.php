<?php
require_once 'DataProvider3.php';

$query = "SELECT * FROM t_book";
$query = $query . " ORDER BY BOOK_TITLE";

$dp = new DataProvider();
$results = $dp->executeQuery($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Kết quả tìm kiếm sách</title>
    <meta charset="utf-8">
</head>
<body>
    
    <table border="1">
        <thead>
            <tr>
                <th>Số thứ tự</th>
                <th>Mã sách</th>
                <th>Tên sách</th>
                <th>Mô tả</th>
                <th>Tác giả</th>
                <th>Nhà xuất bản</th>
                <th>Năm xuất bản</th>
                <th>Giá bán</th>
                <th>Hình ảnh</th>
            </tr>
        </thead>
        <tbody>
            <?php  
            $i=1;
            while ($row = $results->fetch_assoc()) {
               echo "<tr>";
               echo "<td>" . $i . "</td>";
               echo "<td>" . $row['BOOK_ID'] . "</td>";
               echo "<td>" . $row['BOOK_TITLE'] . "</td>";
               echo "<td>" . $row['BOOK_DESC'] . "</td>";
               echo "<td>" . $row['BOOK_AUTHOR'] . "</td>";
               echo "<td>" . $row['BOOK_PUBID'] . "</td>";
               echo "<td>" . $row['BOOK_YEAR'] . "</td>";
               echo "<td>" . $row['BOOK_PRICE'] . "</td>";
               echo "<td><img src='/images/" . $row['BOOK_PIC'] . "'></td>";
               echo "</tr>";
                $i++;
   			}
            ?>
        </tbody>
    </table>
</body>
</html>