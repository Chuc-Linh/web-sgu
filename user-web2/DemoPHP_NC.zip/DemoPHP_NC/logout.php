<?php
session_start();
session_destroy(); // Hủy toàn bộ session
header("Location: login.php");
exit();
?>