<?php
session_start();
require 'DataProvider3.php';

$error = "";
if (isset($_POST['user']) && isset($_POST['pass'])) {
    $u = $_POST['user'];
    $p = $_POST['pass'];

    $dp = new DataProvider();
    // Truy vấn kiểm tra tài khoản (Lưu ý: Trong thực tế nên dùng Password Hash)
    $sql = "SELECT * FROM t_account WHERE ACC_USER='$u' AND ACC_PASS='$p'";
    $result = $dp->executeQuery($sql);

    if ($row = $result->fetch_assoc()) {
        // Đăng nhập thành công: Lưu thông tin vào Session
        $_SESSION['user_id'] = $row['ACC_USER'];
        $_SESSION['user_name'] = $row['ACC_NAME'];

        // Chuyển hướng về trang chủ hoặc trang quản lý
        header("Location: login.php");
        exit();
    } else {
        $error = "Sai tên đăng nhập hoặc mật khẩu!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Đăng nhập hệ thống</title>
    <meta charset="utf-8">
</head>
<body>
    <div style="text-align: center;">
        <?php if (isset($_SESSION['user_id'])): ?>
            <h2>Chào bạn, <?php echo $_SESSION['user_name']; ?>!</h2>
            <p>Bạn hiện có quyền truy cập các chức năng quản trị:</p>
            <ul style="list-style: none;">
                <li><a href="addbook.php">Thêm sách mới</a></li>
                <li><a href="editbook.php">Chỉnh sửa sách</a></li>
                <li><a href="deletebook.php">Xóa sách</a></li>
                <li><hr width="200"></li>
                <li><a href="logout.php">Đăng xuất</a></li>
            </ul>
        <?php else: ?>
            <h2>Đăng nhập hệ thống</h2>
            <?php if($error != "") echo "<p style='color:red'>$error</p>"; ?>
            <form method="post" action="login.php">
                Tài khoản: <input type="text" name="user"><br><br>
                Mật khẩu: <input type="password" name="pass"><br><br>
                <input type="submit" value="Đăng nhập">
            </form>
        <?php endif; ?>

        <p>Chức năng công khai:</p>
        <a href="searchbooks.html">Tìm kiếm sách</a> | <a href="selectsortbooks.php">Sắp xếp sách</a>
    </div>
</body>
</html>
