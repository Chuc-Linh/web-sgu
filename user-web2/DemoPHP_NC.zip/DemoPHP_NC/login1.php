<?php
session_start();
require 'DataProvider3.php';

$error = "";

// Xử lý khi người dùng nhấn nút Đăng nhập
if (isset($_POST['user']) && isset($_POST['pass'])) {
    $u = $_POST['user'];
    $p = $_POST['pass'];

    $dp = new DataProvider();
    // Bước 1: Tìm user trong bảng t_account1
    $sql = "SELECT * FROM t_account1 WHERE ACC_USER = '$u'";
    $result = $dp->executeQuery($sql);

    if ($row = $result->fetch_assoc()) {
        // Bước 2: Kiểm tra mật khẩu mã hóa
        if (password_verify($p, $row['ACC_PASS'])) {

            // Bước 3: Kiểm tra vai trò (Role)
            if ($row['ACC_ROLE'] == 1) {
                // Đăng nhập thành công với quyền Quản trị
                $_SESSION['user_id'] = $row['ACC_USER'];
                $_SESSION['user_name'] = $row['ACC_NAME'];
                $_SESSION['user_role'] = $row['ACC_ROLE'];

                header("Location: login1.php");
                exit();
            } else {
                // Đăng nhập đúng nhưng là Người mua hàng
                $error = "Bạn không có quyền vào hệ thống quản trị.";
            }
        } else {
            // Sai mật khẩu
            //$error = "Mật khẩu không chính xác.";
            $error = "Thông tin đăng nhập không đúng.";
        }
    } else {
        // Không tìm thấy tên đăng nhập
        //$error = "Tên đăng nhập (User ID) không tồn tại.";
        $error = "Thông tin đăng nhập không đúng.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hệ thống quản lý sách - Login</title>
    <meta charset="utf-8">
</head>
<body>
    <div style="text-align: center; margin-top: 50px; font-family: Arial;">
        <?php if (isset($_SESSION['user_id'])): ?>
            <h2 style="color: green;">Chào mừng Quản trị viên: <?php echo $_SESSION['user_name']; ?></h2>
            <div style="background: #f4f4f4; padding: 20px; display: inline-block; border-radius: 10px;">
                <p>Bạn có thể thực hiện các chức năng sau:</p>
                <a href="adduser.php">Cấp tài khoản</a> |
                <a href="addbook.php">Thêm sách mới</a> |
                <a href="editbook.php">Chỉnh sửa sách</a> |
                <a href="deletebook.php">Xóa sách</a>
                <br><br>
                <a href="logout1.php" style="color: red;">Đăng xuất khỏi hệ thống</a>
            </div>
        <?php else: ?>
            <h2>ĐĂNG NHẬP HỆ THỐNG</h2>
            <?php if($error != "") echo "<p style='color:red; font-weight:bold;'>$error</p>"; ?>

            <form method="post" action="login1.php" style="border: 1px solid #ccc; display: inline-block; padding: 30px;">
                Tên đăng nhập:<br>
                <input type="text" name="user" required><br><br>
                Mật khẩu:<br>
                <input type="password" name="pass" required><br><br>
                <input type="submit" value="Đăng nhập">
            </form>
        <?php endif; ?>

        <hr width="500">
        <p><strong>Chức năng dành cho mọi người:</strong></p>
        <a href="searchbooks.html">Tìm kiếm sách</a> | <a href="selectsortbooks.php">Sắp xếp sách</a>
    </div>
</body>
</html>
