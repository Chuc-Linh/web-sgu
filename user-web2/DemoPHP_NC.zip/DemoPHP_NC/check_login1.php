<?php
session_start();
// Chặn nếu: 1. Chưa có session user_id HOẶC 2. Vai trò không phải là 1 (Admin)
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 1) {
    header("Location: login1.php"); // Đứng nguyên hoặc về trang login
    exit();
}
?>