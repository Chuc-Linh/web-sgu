<?php
// Ví dụ tạo mã hash cho mật khẩu '123'
$pass_raw = "123abc";
$pass_hash = password_hash($pass_raw, PASSWORD_DEFAULT);
echo "Mật khẩu gốc: " . $pass_raw . "<br>";
echo "Chuỗi lưu vào DB: " . $pass_hash;
?>