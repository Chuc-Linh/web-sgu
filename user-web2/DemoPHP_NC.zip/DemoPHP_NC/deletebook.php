<?php
require 'check_login.php';
require 'DataProvider3.php';
$dp = new DataProvider();
if (isset($_GET['del_id'])){
	$sql = "DELETE FROM t_book WHERE BOOK_ID=" . $_GET['del_id'];
	//phải hỏi trước khi thực thi nhé
	$results = $dp->executeQuery($sql);
}

$sql = "SELECT * FROM t_book";
$results = $dp->executeQuery($sql);

// Hien thi ket qua
echo '<table width="600" align="center" border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">';
   echo "<tr>";
   echo "<th>STT</th>";
   echo "<th>Tựa sách</th>";   	   
   echo "<th>Mô tả</th>";
   echo "<th>Tác giả</th>";
   echo "<th>NXB</th>";
   echo "<th>Đơn giá</th>";   
   echo "<th>Ảnh bìa</th>";
   echo "</tr>";
   $i = 1;
   while ($row = $results->fetch_array())
   {
   	    echo "<tr>";
   	   	echo "<td>" . $i . "</td>";
   	   	echo "<td>" . $row['BOOK_TITLE'] . "</td>";
   	   	echo "<td>" . $row['BOOK_DESC'] . "</td>";
   	   	echo "<td>" . $row['BOOK_AUTHOR'] . "</td>";
   	   	echo "<td>" . $row['BOOK_YEAR'] . "</td>";
   	   	echo "<td>" . $row['BOOK_PRICE'] . "</td>";
		echo "<td><img src='images/" . $row["BOOK_PIC"] . "'></td>";
		
		echo "<td>";
		echo "<form method='get' action='deletebook.php'>";
		echo "<input type='hidden' name='del_id' value='" . $row["BOOK_ID"] . "'>";
		echo "<input type='submit' value='Xóa'>";
		echo "</form>";
		echo "</td>";

      	echo "</tr>";
      	
      	$i++;
   }
   echo "</table>";

?>